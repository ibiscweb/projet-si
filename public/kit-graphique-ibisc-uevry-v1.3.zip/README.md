# Kit graphique IBISC × UEVRY — v1.3

**Date :** 20 mai 2026
**Auteur :** Frédéric Davesne (Responsable Communication, IBISC)
**Source :** Livre de marque Université Évry Paris-Saclay, mars 2025

---

## Contenu du kit

```
build/
├── ibisc-uevry-tokens.css   ← Tokens canoniques (couleurs, typo, espacement)
├── uevry-fonts.css          ← Déclarations @font-face URW DIN
├── README.md                ← Ce fichier
├── demo.html                ← Démo couleurs + typographie
├── demo-logos.html          ← Démo des logos sur fonds (charte p. 14)
├── fonts/uevry/             ← 7 fichiers WOFF2 (266 Ko, URW DIN)
└── logos/uevry/             ← 3 fichiers SVG officiels UEVRY
    ├── uevry-logo-bleu.svg    (10 Ko, vectorisé)
    ├── uevry-logo-blanc.svg   (3 Ko, texte vivant Open Sans + Yanone)
    └── uevry-logo-noir.svg    (10 Ko, vectorisé)
```

## Référentiel d'usage des logos (charte p. 14)

| Cas d'usage | Fichier à utiliser |
|---|---|
| Fond blanc | `uevry-logo-bleu.svg` |
| Fond couleur unie claire | `uevry-logo-bleu.svg` |
| Fond couleur unie foncée (ex : bleu UEVRY) | `uevry-logo-blanc.svg` |
| Fond complexe (photo, dégradé) | `uevry-logo-blanc.svg` |
| Impression noir et blanc | `uevry-logo-noir.svg` |

### Six interdictions absolues (charte p. 14)

1. Ne pas incliner le logo.
2. Ne pas déformer le logo.
3. Ne pas utiliser une version inappropriée au fond.
4. Ne pas retirer d'éléments.
5. Ne pas changer les couleurs.
6. Ne pas remplacer le nom UEVRY par celui d'une composante.

### Note sur `uevry-logo-blanc.svg`

Cette version contient du texte vivant (polices CSS `Open Sans Bold` et
`Yanone Kaffeesatz Bold`) au lieu de tracés vectoriels. Sur le Web, ce
n'est pas un problème **si** la page charge ces polices en parallèle.
Préchargement recommandé dans le `<head>` :

```html
<link rel="preload" as="font" type="font/woff2" crossorigin
      href="https://fonts.gstatic.com/s/yanonekaffeesatz/...woff2">
<link rel="preload" as="font" type="font/woff2" crossorigin
      href="https://fonts.gstatic.com/s/opensans/...woff2">
```

Alternative : pour un usage à coût zéro de rendu, demander à la DMCom
une version vectorisée du logo blanc (sans texte vivant).

## Point en suspens — couleur du logo

Les fichiers SVG fournis utilisent `#003A69` alors que la charte (p. 15)
indique `#0A3D67` comme couleur principale. Différence imperceptible mais
réelle (3 points RGB d'écart sur le bleu).

**Question à confirmer avec la DMCom :** est-ce une mise à jour
intermédiaire de la charte, ou faut-il aligner le tokens CSS sur
`#003A69` pour cohérence absolue avec les logos officiels ?

En l'attente, les tokens CSS conservent `#0A3D67` (couleur charte) ; les
logos gardent `#003A69` (leur couleur native). Visuellement aligné.

## Intégration — Phase 1 (WordPress + Kadence)

1. Copier les dossiers `fonts/uevry/` et `logos/uevry/` dans le thème
   enfant Kadence :
   ```
   wp-content/themes/ibisc-kadence-child/fonts/uevry/
   wp-content/themes/ibisc-kadence-child/logos/uevry/
   ```
2. Copier `uevry-fonts.css` et `ibisc-uevry-tokens.css` à la racine du
   thème enfant.
3. Dans le `functions.php` du thème enfant :
   ```php
   add_action('wp_enqueue_scripts', function() {
       wp_enqueue_style(
           'ibisc-uevry-tokens',
           get_stylesheet_directory_uri() . '/ibisc-uevry-tokens.css',
           [], '1.3'
       );
   });
   ```
4. Dans Kadence → Apparence → Personnaliser :
   - Typographie : police de base et titres = « URW DIN »
   - Couleurs globales :
     - Couleur 1 (Primaire) : `#0A3D67`
     - Couleur 2 (Accent) : `#5EB1C1`
     - Couleur 3 (Surbrillance) : `#EAB80F`
     - Couleur 4 (Avertissement) : `#D57B16`
5. Footer global : utiliser `uevry-logo-blanc.svg` (footer sur fond bleu
   UEVRY) ou `uevry-logo-bleu.svg` (footer sur fond blanc).

## Intégration — Phase 2 (Astro)

1. Placer les dossiers `fonts/uevry/` et `logos/uevry/` dans `public/`.
2. Placer les CSS dans `src/styles/`.
3. Dans le layout principal :
   ```astro
   ---
   import "../styles/ibisc-uevry-tokens.css";
   ---
   <html>
     <head>
       <link rel="preload" href="/fonts/uevry/URWDIN-Regular.woff2"
             as="font" type="font/woff2" crossorigin>
       <link rel="preload" href="/fonts/uevry/URWDIN-Bold.woff2"
             as="font" type="font/woff2" crossorigin>
     </head>
     <body>
       <slot />
       <footer>
         <hr class="uevry-signature-bar">
         <img src="/logos/uevry/uevry-logo-blanc.svg"
              alt="Université Évry Paris-Saclay">
       </footer>
     </body>
   </html>
   ```

## Points d'attention récapitulatifs

### Licence typographie

Les fichiers URW DIN portent `Copyright 2016 by URW++ Design &
Development GmbH`. Le bit technique `fsType = 0` autorise l'embedding,
mais la licence légale d'utilisation Web doit être confirmée par la
DMCom UEVRY. **Demande envoyée à Aude Escande le 20/05/2026.**

### Italiques manquantes (URW DIN)

Une seule italique fournie (regular 400). Les italiques light, bold,
black sont synthétisées par le navigateur via `font-synthesis: weight
style` (déjà inclus dans `uevry-fonts.css`). Rendu acceptable en
attendant la fourniture éventuelle des fichiers complets.

### Couleur du logo

Écart `#003A69` (SVG) vs `#0A3D67` (charte). Question incluse dans le
mail à la DMCom.

### Condensée black exclue

`urw-din-condensed-black.ttf` écartée du périmètre Web (usage
signalétique imprimée).

## Historique

| Version | Date | Évolutions |
|---|---|---|
| 1.0 | 20/05/2026 | Tokens initiaux, fallback PT Sans Narrow |
| 1.1 | 20/05/2026 | Section UEVRY ajoutée à la proposition technique |
| 1.2 | 20/05/2026 | URW DIN authentique intégrée (7 WOFF2), tokens finalisés |
| 1.3 | 20/05/2026 | Logos UEVRY officiels intégrés (bleu, blanc, noir), `demo-logos.html`, référentiel d'usage selon p. 14 de la charte |
